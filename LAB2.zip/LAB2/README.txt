University of Brasilia
Computer Science Departament
Bachelor student - Otto K. von Sperling

Assignment from Graph Theory course. Implementation of two distinct topological sorting algorithms, their benchmarkings
and plotting the results.
Khan's and Tarjan's algorithms have been choosen.

Compile:
  g++ -std=c++11 -o toposort main.cpp toposort.cpp toposort.hpp gnuplot_i.hpp
